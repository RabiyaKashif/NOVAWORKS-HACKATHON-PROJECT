import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Bell,
  Building2,
  Calculator,
  Calendar,
  ChevronRight,
  Clock,
  Cpu,
  Download,
  Layers,
  ListChecks,
  Lock,
  Plus,
  Shield,
  Users,
  X,
} from 'lucide-react';
import { DemoUser, Project, TaskIconKind, TaskItem, TaskStatus, TeamMember } from '../types';
import { OrbitalBackground } from './OrbitalBackground';

interface TasksScreenProps {
  project: Project;
  allProjects: Project[];
  currentUser: DemoUser;
  isAdminView: boolean;
  teamMembers: TeamMember[];
  onBackToProjects: () => void;
  onSelectProjectId: (id: string) => void;
  onUpdateTask: (projectId: string, updatedTask: TaskItem) => void;
  onAddTask: (projectId: string, newTask: Omit<TaskItem, 'id' | 'code' | 'executionOrder'>) => void;
}

const TASK_STATUS_ORDER: TaskStatus[] = [
  'In Development',
  'Under Review',
  'Completed',
  'Queued',
];

export const TasksScreen: React.FC<TasksScreenProps> = ({
  project,
  allProjects,
  currentUser,
  isAdminView,
  teamMembers,
  onBackToProjects,
  onSelectProjectId,
  onUpdateTask,
  onAddTask,
}) => {
  const [showAllTasks, setShowAllTasks] = useState(false);
  const [sortMode, setSortMode] = useState<'order' | 'deadline' | 'hours'>('order');
  const [activeTaskModal, setActiveTaskModal] = useState<TaskItem | null>(null);
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const [infoModal, setInfoModal] = useState<'audit' | 'specs' | null>(null);

  // Add Task Form State
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newAssigneeName, setNewAssigneeName] = useState(currentUser.name);
  const [newHours, setNewHours] = useState(10);
  const [newDeadline, setNewDeadline] = useState('Nov 22, 2025');
  const [newStatus, setNewStatus] = useState<TaskStatus>('In Development');

  // Filter logic: when isAdminView is false or filter active, show current user's tasks (fallback to Ali Raza if demo user has 0)
  const myTasks = useMemo(() => {
    const direct = project.tasks.filter(
      (t) => t.assigneeName.toLowerCase() === currentUser.name.toLowerCase()
    );
    if (direct.length > 0) return direct;
    // Fallback for projects where currentUser has no tasks yet when switching tabs
    return project.tasks;
  }, [project.tasks, currentUser.name]);

  const effectiveShowAll = showAllTasks || myTasks.length === project.tasks.length;

  const visibleTasks = useMemo(() => {
    const base = effectiveShowAll ? [...project.tasks] : [...myTasks];
    if (sortMode === 'hours') {
      return base.sort((a, b) => b.hours - a.hours);
    }
    if (sortMode === 'deadline') {
      return base.sort((a, b) => a.deadlineSort.localeCompare(b.deadlineSort));
    }
    return base.sort((a, b) => a.executionOrder - b.executionOrder);
  }, [effectiveShowAll, project.tasks, myTasks, sortMode]);

  const sortLabel =
    sortMode === 'order'
      ? 'By Execution Order'
      : sortMode === 'deadline'
        ? 'By Deadline'
        : 'By Effort (Hours)';

  const cycleSort = () => {
    setSortMode((prev) =>
      prev === 'order' ? 'deadline' : prev === 'deadline' ? 'hours' : 'order'
    );
  };

  const renderTaskIcon = (icon: TaskIconKind) => {
    const cls = 'h-4 w-4 text-[#5b3bdf]';
    switch (icon) {
      case 'lock':
        return <Lock className={cls} />;
      case 'calculator':
        return <Calculator className={cls} />;
      case 'bell':
        return <Bell className={cls} />;
      case 'shield':
        return <Shield className={cls} />;
      case 'layers':
        return <Layers className={cls} />;
      default:
        return <Cpu className={cls} />;
    }
  };

  const getStatusTextClasses = (status: TaskStatus) => {
    switch (status) {
      case 'In Development':
        return 'text-[#5b3bdf] hover:text-[#4519ca]';
      case 'Under Review':
        return 'text-[#45464e] hover:text-[#0d1b3e]';
      case 'Completed':
        return 'text-[#15803d] hover:text-[#166534]';
      default:
        return 'text-[#76767f] hover:text-[#0d1b3e]';
    }
  };

  const handleCycleTaskStatus = (e: React.MouseEvent, task: TaskItem) => {
    e.stopPropagation();
    const nextIdx = (TASK_STATUS_ORDER.indexOf(task.status) + 1) % TASK_STATUS_ORDER.length;
    onUpdateTask(project.id, { ...task, status: TASK_STATUS_ORDER[nextIdx] });
  };

  const handleExportManifest = () => {
    const manifest = {
      exportedAt: new Date().toISOString(),
      projectCode: project.code,
      client: project.clientName,
      architecture: project.projectTitle,
      sprint: project.sprintLabel,
      tasks: project.tasks,
    };
    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${project.code.toLowerCase()}-task-manifest.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const member = teamMembers.find((m) => m.name === newAssigneeName);
    onAddTask(project.id, {
      title: newTitle.trim(),
      description:
        newDescription.trim() ||
        'Scoped sprint deliverable synthesized with automated verification gates.',
      status: newStatus,
      assigneeName: member ? member.name : newAssigneeName,
      assigneeInitials: member ? member.initials : 'AR',
      assigneeSpecialty: member ? member.capabilities.slice(0, 2).join(' / ') : 'Engineering',
      hours: Number(newHours) || 8,
      deadline: newDeadline || 'Nov 28, 2025',
      deadlineSort: '2025-11-28',
      icon: 'layers',
    });
    setNewTitle('');
    setNewDescription('');
    setShowAddTaskModal(false);
  };

  const viewerLabel =
    currentUser.role === 'DEVELOPER'
      ? 'Developer'
      : currentUser.role === 'MANAGER'
        ? 'Manager'
        : 'Admin';

  return (
    <div className="relative overflow-hidden">
      <OrbitalBackground variant="subpage" />

      <div className="relative z-10 mx-auto max-w-[1220px] px-5 pt-7 pb-12 sm:px-8">
        {/* Top Breadcrumb & Status Badges */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2 text-xs text-[#45464e]">
            <button
              type="button"
              onClick={onBackToProjects}
              className="inline-flex items-center gap-1.5 font-medium text-[#0d1b3e] hover:text-[#5b3bdf] transition-colors"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to Projects
            </button>
            <span className="text-[#c6c6cf]" aria-hidden="true">/</span>
            <select
              aria-label="Switch active client project"
              value={project.id}
              onChange={(e) => onSelectProjectId(e.target.value)}
              className="cursor-pointer rounded-lg bg-transparent py-0.5 font-medium text-[#45464e] hover:text-[#0d1b3e] focus:outline-none"
            >
              {allProjects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.clientName}
                </option>
              ))}
            </select>
            <span className="text-[#c6c6cf]" aria-hidden="true">/</span>
            <span className="font-semibold text-[#0d1b3e]">{project.projectTitle}</span>
          </div>
        </div>

        {/* Project Architecture Hero Header */}
        <section className="mt-8 flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-2xl">
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#5b3bdf]">
              PROJECT ARCHITECTURE • {project.code}
            </p>
            <h1 className="mt-2 font-editorial text-[42px] leading-[1.06] tracking-[-0.02em] text-[#0d1b3e] sm:text-[54px] text-balance">
              {project.projectTitle}
            </h1>
            <p className="mt-3 max-w-[560px] text-[15px] leading-relaxed text-[#45464e]">
              {project.architectureSummary}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handleExportManifest}
              className="inline-flex items-center gap-3 rounded-full bg-[#0d1b3e] py-2 pl-5 pr-2 text-xs font-semibold text-white shadow-[0_12px_24px_-6px_rgba(13,27,62,0.25)] transition-colors hover:bg-[#162756] whitespace-nowrap shrink-0"
            >
              <span>Export Task Manifest</span>
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#6344e7] text-white">
                <Download className="h-3.5 w-3.5" />
              </span>
            </button>

            <button
              type="button"
              onClick={() => setShowAddTaskModal(true)}
              className="inline-flex items-center gap-3 rounded-full border border-[#0d1b3e]/12 bg-white py-2 pl-4 pr-2 text-xs font-semibold text-[#0d1b3e] shadow-[0_4px_14px_-6px_rgba(13,27,62,0.08)] transition-colors hover:bg-[#f5f4f0] whitespace-nowrap shrink-0"
            >
              <span>Add Task</span>
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#0d1b3e] text-white">
                <Plus className="h-3.5 w-3.5" />
              </span>
            </button>
          </div>
        </section>

        {/* 4-Column KPI Metadata Strip */}
        <section className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border border-[#0d1b3e]/[0.07] bg-white p-5 shadow-[0_4px_18px_-8px_rgba(13,27,62,0.05)]">
            <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#76767f]">
              <Users className="h-3.5 w-3.5 text-[#5b3bdf]" />
              <span>ASSIGNED LEAD</span>
            </div>
            <p className="mt-2.5 text-[15px] font-semibold text-[#0d1b3e]">
              {project.deliveryLeadName}
            </p>
            <p className="mt-0.5 text-xs text-[#45464e]">{project.deliveryLeadRole}</p>
          </div>

          <div className="rounded-2xl border border-[#0d1b3e]/[0.07] bg-white p-5 shadow-[0_4px_18px_-8px_rgba(13,27,62,0.05)]">
            <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#76767f]">
              <Calendar className="h-3.5 w-3.5 text-[#5b3bdf]" />
              <span>TARGET DELIVERY</span>
            </div>
            <p className="mt-2.5 text-[15px] font-semibold text-[#0d1b3e] tabular-nums">
              {project.targetDelivery}
            </p>
            <p className="mt-0.5 text-xs text-[#45464e]">Milestone Sprint 4</p>
          </div>

          <div className="rounded-2xl border border-[#0d1b3e]/[0.07] bg-white p-5 shadow-[0_4px_18px_-8px_rgba(13,27,62,0.05)]">
            <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#76767f]">
              <Building2 className="h-3.5 w-3.5 text-[#5b3bdf]" />
              <span>CLIENT CONTACT</span>
            </div>
            <p className="mt-2.5 text-[15px] font-semibold text-[#0d1b3e]">
              {project.clientContactName}
            </p>
            <p className="mt-0.5 text-xs text-[#45464e] truncate">{project.clientContactEmail}</p>
          </div>

          <div className="rounded-2xl border border-[#0d1b3e]/[0.07] bg-white p-5 shadow-[0_4px_18px_-8px_rgba(13,27,62,0.05)]">
            <div className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#76767f]">
              <ListChecks className="h-3.5 w-3.5 text-[#5b3bdf]" />
              <span>SCOPE INVENTORY</span>
            </div>
            <p className="mt-2.5 text-[15px] font-semibold text-[#0d1b3e] tabular-nums">
              {project.tasks.length} Open Tasks
            </p>
            <p className="mt-0.5 text-xs text-[#45464e] tabular-nums">
              {project.closedCount} Closed • {project.underReviewCount} Under Review
            </p>
          </div>
        </section>

        {/* Active Viewer Filter Bar */}
        <div className="mt-6 flex flex-col justify-between gap-3 rounded-3xl border border-[#0d1b3e]/[0.07] bg-white px-5 py-3.5 shadow-[0_4px_18px_-10px_rgba(13,27,62,0.06)] sm:flex-row sm:items-center">
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#6344e7] text-[11px] font-semibold text-white">
              {currentUser.initials}
            </span>
            <span className="text-[#45464e]">
              Viewing as{' '}
              <strong className="font-semibold text-[#0d1b3e]">
                {currentUser.name} ({viewerLabel})
              </strong>
            </span>
            <span className="text-[#c6c6cf]" aria-hidden="true">•</span>
            <span className="font-medium text-[#5b3bdf]">
              Filter active: &ldquo;
              {effectiveShowAll ? 'All Sprint Tasks' : 'My Assigned Tasks Only'}&rdquo; (
              {visibleTasks.length} of {project.tasks.length} tasks displayed)
            </span>
          </div>

          <button
            type="button"
            onClick={() => setShowAllTasks((prev) => !prev)}
            className="rounded-full border border-[#0d1b3e]/12 bg-[#faf9f5] px-4 py-1.5 text-xs font-medium text-[#0d1b3e] transition-colors hover:bg-[#efeeea] whitespace-nowrap shrink-0"
          >
            {effectiveShowAll
              ? myTasks.length < project.tasks.length
                ? `Show My Tasks (${myTasks.length})`
                : `All Tasks (${project.tasks.length})`
              : `Show All Tasks (${project.tasks.length})`}
          </button>
        </div>

        {/* Backlog & Execution Manifest Table Card */}
        <section className="mt-5 overflow-hidden rounded-[1.75rem] border border-[#0d1b3e]/[0.07] bg-white shadow-[0_12px_36px_-16px_rgba(13,27,62,0.08)]">
          {/* Card Header */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#0d1b3e]/[0.06] px-6 py-4">
            <div className="flex items-center gap-2.5">
              <h2 className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#0d1b3e]">
                BACKLOG &amp; EXECUTION MANIFEST
              </h2>
              <span className="text-[#c6c6cf]" aria-hidden="true">·</span>
              <span className="text-xs font-medium text-[#76767f]">
                {project.sprintLabel}
              </span>
            </div>

            <button
              type="button"
              onClick={cycleSort}
              className="text-xs font-medium text-[#76767f] hover:text-[#0d1b3e] transition-colors"
            >
              Sort: <span className="text-[#0d1b3e]">{sortLabel}</span>
            </button>
          </div>

          {/* Task Rows */}
          <div className="divide-y divide-[#0d1b3e]/[0.06]">
            {visibleTasks.map((task) => (
              <div
                key={task.id}
                onClick={() => setActiveTaskModal(task)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setActiveTaskModal(task);
                  }
                }}
                className="group flex cursor-pointer flex-col justify-between gap-4 px-6 py-5 transition-colors hover:bg-[#faf9f5]/80 lg:flex-row lg:items-center"
              >
                {/* Left Content */}
                <div className="flex items-start gap-4 min-w-0">
                  <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#f1edff]">
                    {renderTaskIcon(task.icon)}
                  </div>

                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-[11px] font-medium tracking-[0.18em] text-[#76767f] tabular-nums">
                        {task.code.replace('-', ' - ')}
                      </span>
                      <span className="text-[#c6c6cf]" aria-hidden="true">·</span>
                      <button
                        type="button"
                        onClick={(e) => handleCycleTaskStatus(e, task)}
                        title="Click to cycle task status"
                        className={`text-[11px] font-semibold transition-colors hover:underline ${getStatusTextClasses(
                          task.status
                        )}`}
                      >
                        {task.status}
                      </button>
                    </div>

                    <h3 className="mt-1.5 text-[16px] font-semibold tracking-[-0.01em] text-[#0d1b3e] group-hover:text-[#5b3bdf] transition-colors">
                      {task.title}
                    </h3>
                    <p className="mt-1 max-w-xl text-[13px] leading-relaxed text-[#45464e]">
                      {task.description}
                    </p>
                  </div>
                </div>

                {/* Right Assignee + Hours + Deadline */}
                <div className="flex flex-wrap items-center justify-between gap-5 pl-13 lg:justify-end lg:pl-0 shrink-0">
                  <div className="flex items-center gap-2.5">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#0d1b3e] text-[10px] font-semibold text-white">
                      {task.assigneeInitials}
                    </span>
                    <div>
                      <p className="text-xs font-semibold text-[#0d1b3e] leading-tight">
                        {task.assigneeName}
                      </p>
                      <p className="text-[11px] text-[#76767f] leading-tight">
                        {task.assigneeSpecialty}
                      </p>
                    </div>
                  </div>

                  <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#45464e] tabular-nums">
                    <Clock className="h-3.5 w-3.5 text-[#76767f]" />
                    {task.hours} hrs
                  </span>

                  <div className="text-right tabular-nums">
                    <p className="text-[10px] text-[#76767f]">Deadline</p>
                    <p className="text-xs font-semibold text-[#0d1b3e]">{task.deadline}</p>
                  </div>

                  <ChevronRight className="h-4 w-4 text-[#76767f] transition-transform group-hover:translate-x-0.5 group-hover:text-[#0d1b3e]" />
                </div>
              </div>
            ))}
          </div>

          {/* Card Footer */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#0d1b3e]/[0.06] bg-[#faf9f5]/50 px-6 py-3.5 text-xs text-[#45464e]">
            <span className="tabular-nums">
              Showing <strong className="font-semibold text-[#0d1b3e]">{visibleTasks.length}</strong> of{' '}
              {project.tasks.length} tasks
            </span>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setInfoModal('audit')}
                className="rounded-full border border-[#0d1b3e]/10 bg-white px-3.5 py-1 text-xs font-medium text-[#0d1b3e] hover:bg-[#f5f4f0] transition-colors"
              >
                Audit Log
              </button>
              <button
                type="button"
                onClick={() => setInfoModal('specs')}
                className="rounded-full border border-[#0d1b3e]/10 bg-white px-3.5 py-1 text-xs font-medium text-[#0d1b3e] hover:bg-[#f5f4f0] transition-colors"
              >
                Sprint Specs
              </button>
            </div>
          </div>
        </section>
      </div>

      {/* Task Detail Drawer / Modal */}
      {activeTaskModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-end bg-[#0d1b3e]/35 backdrop-blur-xs"
          onClick={() => setActiveTaskModal(null)}
        >
          <div
            className="flex h-full w-full max-w-md flex-col justify-between bg-white p-6 shadow-2xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <div className="flex items-center justify-between gap-3 border-b border-[#0d1b3e]/[0.07] pb-4">
                <span className="font-mono text-xs font-semibold tracking-widest text-[#5b3bdf]">
                  {activeTaskModal.code}
                </span>
                <button
                  type="button"
                  onClick={() => setActiveTaskModal(null)}
                  aria-label="Close task inspector"
                  className="rounded-full p-1.5 text-[#76767f] hover:bg-[#f5f4f0] hover:text-[#0d1b3e]"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <h3 className="mt-5 font-editorial text-2xl text-[#0d1b3e]">
                {activeTaskModal.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-[#45464e]">
                {activeTaskModal.description}
              </p>

              <div className="mt-6 space-y-4">
                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-[#76767f]">
                    Execution Status
                  </label>
                  <div className="mt-2 grid grid-cols-2 gap-2">
                    {TASK_STATUS_ORDER.map((st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => {
                          const updated = { ...activeTaskModal, status: st };
                          setActiveTaskModal(updated);
                          onUpdateTask(project.id, updated);
                        }}
                        className={`rounded-xl border px-3 py-2 text-xs font-medium transition-colors ${
                          activeTaskModal.status === st
                            ? 'border-[#5b3bdf] bg-[#f1edff] text-[#5b3bdf]'
                            : 'border-[#0d1b3e]/10 bg-white text-[#45464e] hover:bg-[#faf9f5]'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-[#76767f]">
                    Assigned Specialist
                  </label>
                  <select
                    value={activeTaskModal.assigneeName}
                    onChange={(e) => {
                      const member = teamMembers.find((m) => m.name === e.target.value);
                      if (!member) return;
                      const updated: TaskItem = {
                        ...activeTaskModal,
                        assigneeName: member.name,
                        assigneeInitials: member.initials,
                        assigneeSpecialty: member.capabilities.slice(0, 2).join(' / '),
                      };
                      setActiveTaskModal(updated);
                      onUpdateTask(project.id, updated);
                    }}
                    className="mt-2 w-full rounded-xl border border-[#0d1b3e]/12 bg-[#faf9f5] px-3.5 py-2.5 text-sm text-[#0d1b3e] focus:outline-none"
                  >
                    {teamMembers.map((m) => (
                      <option key={m.id} value={m.name}>
                        {m.name} — {m.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl bg-[#f5f4f0] p-3">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-[#76767f]">
                      Estimate
                    </p>
                    <p className="mt-1 text-sm font-semibold text-[#0d1b3e] tabular-nums">
                      {activeTaskModal.hours} hrs
                    </p>
                  </div>
                  <div className="rounded-xl bg-[#f5f4f0] p-3">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-[#76767f]">
                      Deadline
                    </p>
                    <p className="mt-1 text-sm font-semibold text-[#0d1b3e] tabular-nums">
                      {activeTaskModal.deadline}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setActiveTaskModal(null)}
              className="mt-8 w-full rounded-full bg-[#0d1b3e] py-2.5 text-xs font-semibold text-white hover:bg-[#162756]"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Add Task Modal */}
      {showAddTaskModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#0d1b3e]/35 p-4 backdrop-blur-xs"
          onClick={() => setShowAddTaskModal(false)}
        >
          <div
            className="w-full max-w-lg rounded-3xl border border-[#0d1b3e]/10 bg-white p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#5b3bdf]">
                  {project.code} • {project.sprintLabel}
                </p>
                <h3 className="mt-1 font-editorial text-2xl text-[#0d1b3e]">
                  Add Sprint Work Package
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddTaskModal(false)}
                className="rounded-full p-2 text-[#76767f] hover:bg-[#f5f4f0]"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="mt-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#0d1b3e]">Task Title</label>
                <input
                  required
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g., Hardware Key Rotation Telemetry Hook"
                  className="mt-1.5 w-full rounded-xl border border-[#0d1b3e]/12 bg-[#faf9f5] px-3.5 py-2 text-sm text-[#0d1b3e] focus:outline-none focus:ring-2 focus:ring-[#6344e7]/20"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#0d1b3e]">
                  Technical Specification
                </label>
                <textarea
                  rows={3}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Describe architectural boundaries and acceptance criteria..."
                  className="mt-1.5 w-full rounded-xl border border-[#0d1b3e]/12 bg-[#faf9f5] px-3.5 py-2 text-sm text-[#0d1b3e] focus:outline-none focus:ring-2 focus:ring-[#6344e7]/20"
                />
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <label className="block text-xs font-medium text-[#0d1b3e]">Assignee</label>
                  <select
                    value={newAssigneeName}
                    onChange={(e) => setNewAssigneeName(e.target.value)}
                    className="mt-1.5 w-full rounded-xl border border-[#0d1b3e]/12 bg-[#faf9f5] px-3 py-2 text-xs text-[#0d1b3e]"
                  >
                    {teamMembers.map((m) => (
                      <option key={m.id} value={m.name}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#0d1b3e]">Est. Hours</label>
                  <input
                    type="number"
                    min={1}
                    max={80}
                    value={newHours}
                    onChange={(e) => setNewHours(Number(e.target.value))}
                    className="mt-1.5 w-full rounded-xl border border-[#0d1b3e]/12 bg-[#faf9f5] px-3 py-2 text-xs text-[#0d1b3e]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#0d1b3e]">Status</label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as TaskStatus)}
                    className="mt-1.5 w-full rounded-xl border border-[#0d1b3e]/12 bg-[#faf9f5] px-3 py-2 text-xs text-[#0d1b3e]"
                  >
                    {TASK_STATUS_ORDER.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#0d1b3e]">Target Deadline</label>
                <input
                  type="text"
                  value={newDeadline}
                  onChange={(e) => setNewDeadline(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border border-[#0d1b3e]/12 bg-[#faf9f5] px-3.5 py-2 text-xs text-[#0d1b3e]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddTaskModal(false)}
                  className="rounded-full px-4 py-2 text-xs font-medium text-[#45464e] hover:bg-[#f5f4f0]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-full bg-[#0d1b3e] px-5 py-2 text-xs font-semibold text-white hover:bg-[#162756]"
                >
                  Add to Manifest
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Audit Log / Sprint Specs Modal */}
      {infoModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#0d1b3e]/35 p-4 backdrop-blur-xs"
          onClick={() => setInfoModal(null)}
        >
          <div
            className="w-full max-w-lg rounded-3xl border border-[#0d1b3e]/10 bg-white p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#5b3bdf]">
                  {project.code} • {project.projectTitle}
                </p>
                <h3 className="mt-1 font-editorial text-2xl text-[#0d1b3e]">
                  {infoModal === 'audit' ? 'Cryptographic Audit Log' : 'Sprint Architecture Specs'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setInfoModal(null)}
                className="rounded-full p-2 text-[#76767f] hover:bg-[#f5f4f0]"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-5 space-y-3">
              {infoModal === 'audit' ? (
                project.auditLog.map((entry) => (
                  <div
                    key={entry.id}
                    className="rounded-2xl border border-[#0d1b3e]/[0.06] bg-[#faf9f5] p-3.5"
                  >
                    <div className="flex items-center justify-between gap-2 text-[11px] text-[#76767f] tabular-nums">
                      <span className="font-semibold text-[#0d1b3e]">{entry.actor}</span>
                      <span>{entry.timestamp}</span>
                    </div>
                    <p className="mt-1 text-xs font-medium text-[#0d1b3e]">{entry.action}</p>
                    <p className="mt-0.5 text-xs text-[#45464e]">{entry.detail}</p>
                  </div>
                ))
              ) : (
                <ul className="space-y-2.5">
                  {project.sprintSpecs.map((spec, idx) => (
                    <li
                      key={idx}
                      className="flex items-start gap-3 rounded-2xl border border-[#0d1b3e]/[0.06] bg-[#faf9f5] p-3.5 text-xs leading-relaxed text-[#0d1b3e]"
                    >
                      <span className="mt-0.5 font-mono text-[11px] font-semibold text-[#5b3bdf]">
                        0{idx + 1}
                      </span>
                      <span>{spec}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className="mt-6 flex justify-end">
              <button
                type="button"
                onClick={() => setInfoModal(null)}
                className="rounded-full bg-[#0d1b3e] px-5 py-2 text-xs font-semibold text-white hover:bg-[#162756]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
