import React, { useEffect, useRef, useState } from 'react';
import { LogOut, ShieldCheck, User, Users } from 'lucide-react';
import { AppScreen, DemoUser } from '../types';
import { NovaWorksLogo } from './NovaWorksLogo';

interface TopNavBarProps {
  activeScreen: AppScreen;
  onNavigate: (screen: AppScreen) => void;
  isAdminView: boolean;
  onToggleAdminView: () => void;
  currentUser: DemoUser;
  onOpenSignIn: () => void;
  onQuickSwitchUser: (user: DemoUser) => void;
  demoUsers: DemoUser[];
}

export const TopNavBar: React.FC<TopNavBarProps> = ({
  activeScreen,
  onNavigate,
  isAdminView,
  onToggleAdminView,
  currentUser,
  onOpenSignIn,
  onQuickSwitchUser,
  demoUsers,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [menuOpen]);

  const navItems: { id: AppScreen; label: string }[] = [
    { id: 'projects', label: 'Projects' },
    { id: 'tasks', label: 'Tasks' },
    { id: 'team', label: 'Team Directory' },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-[#0d1b3e]/[0.07] bg-[#faf9f5]/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1340px] items-center justify-between gap-4 px-5 py-3.5 sm:px-8">
        {/* Left Zone: Brand */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('projects')}
            className="flex items-center rounded-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6344e7]"
          >
            <NovaWorksLogo size="sm" />
          </button>
        </div>

        {/* Center Zone: Floating Pill Segmented Navigation */}
        <nav
          aria-label="Primary Workspace Navigation"
          className="flex items-center gap-1 rounded-full border border-[#0d1b3e]/[0.08] bg-[#f5f4f0]/90 p-1 shadow-[0_2px_10px_-4px_rgba(13,27,62,0.06)]"
        >
          {navItems.map((item) => {
            const isActive = activeScreen === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-all duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6344e7] ${
                  isActive
                    ? 'bg-white text-[#0d1b3e] font-semibold shadow-[0_1px_4px_rgba(13,27,62,0.08)]'
                    : 'text-[#45464e] hover:text-[#0d1b3e]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Right Zone: Admin View Toggle + Profile Menu */}
        <div className="flex items-center gap-2.5 shrink-0" ref={menuRef}>
          <button
            type="button"
            onClick={onToggleAdminView}
            aria-pressed={isAdminView}
            className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-all duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6344e7] ${
              isAdminView
                ? 'bg-[#0d1b3e] text-white shadow-[0_4px_12px_-3px_rgba(13,27,62,0.28)] hover:bg-[#162756]'
                : 'border border-[#0d1b3e]/15 bg-white text-[#0d1b3e] hover:bg-[#f5f4f0]'
            }`}
          >
            {isAdminView ? 'Admin View' : 'Operator View'}
          </button>

          <div className="relative">
            <button
              type="button"
              onClick={() => setMenuOpen((prev) => !prev)}
              aria-expanded={menuOpen}
              aria-label="Account and role menu"
              className="flex h-8 w-8 items-center justify-center rounded-full bg-[#0d1b3e] text-white transition-transform duration-150 hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6344e7]"
            >
              <User className="h-4 w-4" />
            </button>

            {menuOpen && (
              <div className="absolute right-0 mt-2.5 w-72 rounded-2xl border border-[#0d1b3e]/10 bg-white p-2 shadow-[0_18px_40px_-12px_rgba(13,27,62,0.18)]">
                <div className="border-b border-[#0d1b3e]/[0.07] px-3 py-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-[#0d1b3e] truncate">{currentUser.name}</p>
                    <span className="text-[10px] font-semibold tracking-wider text-[#5b3bdf]">
                      {currentUser.role}
                    </span>
                  </div>
                  <p className="mt-0.5 text-xs text-[#45464e] truncate">{currentUser.email}</p>
                </div>

                <div className="py-1.5">
                  <p className="px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-[#76767f]">
                    Switch Active Persona
                  </p>
                  {demoUsers.map((user) => {
                    const selected = user.id === currentUser.id;
                    return (
                      <button
                        key={user.id}
                        type="button"
                        onClick={() => {
                          onQuickSwitchUser(user);
                          setMenuOpen(false);
                        }}
                        className={`flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-xs transition-colors ${
                          selected
                            ? 'bg-[#f5f4f0] font-semibold text-[#0d1b3e]'
                            : 'text-[#45464e] hover:bg-[#faf9f5] hover:text-[#0d1b3e]'
                        }`}
                      >
                        <span className="flex items-center gap-2 min-w-0">
                          <Users className="h-3.5 w-3.5 text-[#5b3bdf] shrink-0" />
                          <span className="truncate">{user.name}</span>
                        </span>
                        <span className="text-[10px] font-medium text-[#76767f] shrink-0">
                          {user.roleLabel}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <div className="border-t border-[#0d1b3e]/[0.07] pt-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      onOpenSignIn();
                    }}
                    className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-xs font-medium text-[#0d1b3e] hover:bg-[#f5f4f0] transition-colors"
                  >
                    <span className="flex items-center gap-2">
                      <LogOut className="h-3.5 w-3.5 text-[#5b3bdf]" />
                      Sign in / Switch OS Session
                    </span>
                    <ShieldCheck className="h-3.5 w-3.5 text-[#76767f]" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
