import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  Calendar,
  CheckCircle2,
  FileText,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Upload,
  X,
} from 'lucide-react';
import { DEMO_TRANSCRIPTS } from '../data/mockData';
import { Project } from '../types';
import { OrbitalBackground } from './OrbitalBackground';

interface ProjectsScreenProps {
  projects: Project[];
  onSelectProject: (projectId: string) => void;
  onCreateProjectFromTranscript: (transcript: string) => Project;
}

export const ProjectsScreen: React.FC<ProjectsScreenProps> = ({
  projects,
  onSelectProject,
  onCreateProjectFromTranscript,
}) => {
  const [transcript, setTranscript] = useState('');
  const [demoIndex, setDemoIndex] = useState(0);
  const [synthesisBanner, setSynthesisBanner] = useState<string | null>(
    'Apex Capital (Fintech Micro-Invest iOS App) successfully synthesized with 8 milestone work packages and verified team allocations.'
  );
  const [isSynthesizing, setIsSynthesizing] = useState(false);
  const [progressPercent, setProgressPercent] = useState(85);
  const [progressDetail, setProgressDetail] = useState(
    'Extracting architecture scope & matching developer skill profiles...'
  );
  const [transcriptError, setTranscriptError] = useState<string | null>(null);

  const [generatorConfigOpen, setGeneratorConfigOpen] = useState(false);
  const [autoNotifyTeam, setAutoNotifyTeam] = useState(true);
  const [sprintBaselineMode, setSprintBaselineMode] = useState<'Sprint Alpha' | 'Rapid 2-Week'>(
    'Sprint Alpha'
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [filterMenuOpen, setFilterMenuOpen] = useState(false);

  const availableStatuses = useMemo(() => {
    const unique = Array.from(new Set(projects.map((p) => p.statusLabel)));
    return ['ALL', ...unique];
  }, [projects]);

  const filteredProjects = useMemo(() => {
    return projects.filter((project) => {
      const q = searchQuery.trim().toLowerCase();
      const matchesQuery =
        !q ||
        project.clientName.toLowerCase().includes(q) ||
        project.projectTitle.toLowerCase().includes(q) ||
        project.summary.toLowerCase().includes(q) ||
        project.leadName.toLowerCase().includes(q) ||
        project.stackTags.some((tag) => tag.toLowerCase().includes(q));
      const matchesStatus = statusFilter === 'ALL' || project.statusLabel === statusFilter;
      return matchesQuery && matchesStatus;
    });
  }, [projects, searchQuery, statusFilter]);

  const handleInsertDemoTranscript = () => {
    const sample = DEMO_TRANSCRIPTS[demoIndex % DEMO_TRANSCRIPTS.length];
    setTranscript(sample.text);
    setDemoIndex((prev) => prev + 1);
    setTranscriptError(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setTranscript(reader.result);
        setTranscriptError(null);
      }
    };
    reader.readAsText(file);
  };

  const handleSynthesize = () => {
    if (!transcript.trim()) {
      setTranscriptError('Paste meeting notes or click "Insert Demo Transcript" to run synthesis.');
      return;
    }
    setTranscriptError(null);
    setIsSynthesizing(true);
    setProgressPercent(45);
    setProgressDetail('Tokenizing stakeholder scope & extracting technical stack...');

    setTimeout(() => {
      setProgressPercent(92);
      setProgressDetail('Assigning specialists & compiling milestone sprint manifest...');
    }, 350);

    setTimeout(() => {
      const created = onCreateProjectFromTranscript(transcript);
      setIsSynthesizing(false);
      setProgressPercent(100);
      setProgressDetail(
        `${created.clientName} (${created.projectTitle}) synthesized and dispatched to Active Engagements.`
      );
      setSynthesisBanner(
        `${created.clientName} (${created.projectTitle}) successfully synthesized with ${created.tasks.length} milestone work packages and verified team allocations.`
      );
      setTranscript('');
    }, 800);
  };

  const activeSegments =
    progressPercent >= 95 ? 4 : progressPercent >= 70 ? 3 : progressPercent >= 40 ? 2 : 1;

  return (
    <div className="relative overflow-hidden">
      <OrbitalBackground variant="hero" />

      <div className="relative z-10 mx-auto max-w-[1240px] px-5 pt-10 pb-12 sm:px-8 sm:pt-14">
        {/* Hero Header */}
        <section className="mx-auto max-w-2xl text-center">
          <h1 className="mt-2 font-editorial text-[44px] leading-[1.05] tracking-[-0.02em] text-[#0d1b3e] sm:text-[62px] text-balance">
            Dashboard &amp; Operations
          </h1>

          <p className="mx-auto mt-4 max-w-[540px] text-[15px] leading-relaxed text-[#45464e]">
            Autonomous meeting-to-execution pipeline coordinating institutional project
            architecture and engineering assignments.
          </p>
        </section>

        {/* AI Meeting-to-Project Generator Card */}
        <section className="mx-auto mt-10 max-w-[900px]" aria-label="AI Meeting-to-Project Generator">
          <div className="rounded-[1.75rem] border border-[#0d1b3e]/[0.07] bg-white p-6 shadow-[0_14px_40px_-16px_rgba(13,27,62,0.09)] sm:p-8">
            {/* Generator Header */}
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
              <div className="flex items-start gap-3.5">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#f1edff] text-[#5b3bdf]">
                  <Sparkles className="h-4.5 w-4.5" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2.5">
                    <h2 className="font-editorial text-[24px] leading-tight text-[#0d1b3e]">
                      AI Meeting-to-Project Generator
                    </h2>
                    <span className="text-xs font-medium text-[#76767f]">
                      · v2.4 Engine
                    </span>
                  </div>
                  <p className="mt-1 text-[13px] text-[#45464e]">
                    Parse client video calls, sync transcripts, and construct fully phased delivery sprints in moments.
                  </p>
                </div>
              </div>

              <div className="relative flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleInsertDemoTranscript}
                  className="inline-flex items-center gap-2 rounded-full border border-[#0d1b3e]/12 bg-white px-4 py-2 text-xs font-medium text-[#0d1b3e] transition-colors hover:bg-[#f5f4f0] whitespace-nowrap shrink-0"
                >
                  <FileText className="h-3.5 w-3.5 text-[#5b3bdf]" />
                  Insert Demo Transcript
                </button>
                <button
                  type="button"
                  onClick={() => setGeneratorConfigOpen((prev) => !prev)}
                  aria-label="Configure synthesis options"
                  aria-expanded={generatorConfigOpen}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-[#0d1b3e]/12 bg-white text-[#45464e] transition-colors hover:bg-[#f5f4f0] hover:text-[#0d1b3e]"
                >
                  <SlidersHorizontal className="h-3.5 w-3.5" />
                </button>

                {generatorConfigOpen && (
                  <div className="absolute right-0 top-11 z-20 w-64 rounded-2xl border border-[#0d1b3e]/10 bg-white p-3.5 shadow-xl">
                    <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-[#76767f]">
                      Synthesis Parameters
                    </p>
                    <div className="mt-3 space-y-3 text-xs">
                      <label className="flex items-center justify-between gap-2 text-[#0d1b3e]">
                        <span>Auto-notify squad</span>
                        <input
                          type="checkbox"
                          checked={autoNotifyTeam}
                          onChange={(e) => setAutoNotifyTeam(e.target.checked)}
                          className="accent-[#5b3bdf]"
                        />
                      </label>
                      <div>
                        <span className="block text-[#45464e] mb-1.5">Sprint Baseline</span>
                        <div className="grid grid-cols-2 gap-1 rounded-xl bg-[#f5f4f0] p-1">
                          {(['Sprint Alpha', 'Rapid 2-Week'] as const).map((mode) => (
                            <button
                              key={mode}
                              type="button"
                              onClick={() => setSprintBaselineMode(mode)}
                              className={`rounded-lg px-2 py-1 text-[11px] font-medium transition-colors ${
                                sprintBaselineMode === mode
                                  ? 'bg-white text-[#0d1b3e] shadow-xs'
                                  : 'text-[#45464e]'
                              }`}
                            >
                              {mode}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Dismissible Success Banner */}
            {synthesisBanner && (
              <div className="mt-5 flex items-center justify-between gap-3 rounded-2xl border border-[#6344e7]/15 bg-[#f7f5ff] px-4 py-3 text-xs text-[#23005c]">
                <div className="flex items-center gap-2.5 min-w-0">
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-[#5b3bdf]" />
                  <p className="leading-snug">{synthesisBanner}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSynthesisBanner(null)}
                  aria-label="Dismiss notification"
                  className="shrink-0 rounded-full p-1 text-[#5b3bdf]/70 hover:bg-[#e5deff] hover:text-[#23005c]"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            {/* Transcript Input Box */}
            <div className="mt-4 overflow-hidden rounded-2xl border border-[#0d1b3e]/[0.09] bg-[#faf9f5]/75 transition-shadow focus-within:border-[#6344e7]/40 focus-within:ring-3 focus-within:ring-[#6344e7]/12">
              <textarea
                rows={4}
                value={transcript}
                onChange={(e) => {
                  setTranscript(e.target.value);
                  if (transcriptError) setTranscriptError(null);
                }}
                placeholder="Paste meeting transcript or scope notes here... (e.g. 'OmniCorp requested an encrypted multi-region audit vault on AWS by Q3...')"
                className="w-full resize-none bg-transparent px-4 pt-4 pb-3 text-[13px] leading-relaxed text-[#0d1b3e] placeholder:text-[#76767f]/80 focus:outline-none"
              />
              <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#0d1b3e]/[0.06] bg-white/60 px-4 py-2 text-[11px] text-[#76767f]">
                <div className="flex items-center gap-2">
                  <label className="inline-flex cursor-pointer items-center gap-1.5 text-[#45464e] hover:text-[#5b3bdf] transition-colors">
                    <Upload className="h-3.5 w-3.5" />
                    <span>Audio / Text / VTT</span>
                    <input
                      type="file"
                      accept=".txt,.vtt,.md"
                      onChange={handleFileUpload}
                      className="sr-only"
                    />
                  </label>
                  <span aria-hidden="true">•</span>
                  <span>Automatic Role Extraction</span>
                </div>
                <span className="tabular-nums font-medium text-[#76767f]">
                  {transcript.length} characters
                </span>
              </div>
            </div>

            {transcriptError && (
              <p className="mt-2 text-xs font-medium text-[#ba1a1a]">{transcriptError}</p>
            )}

            {/* Processing Bar */}
            <div className="mt-4 flex flex-col justify-between gap-3 rounded-2xl bg-[#f5f4f0] px-4 py-3.5 sm:flex-row sm:items-center">
              <div className="flex items-start gap-3">
                <span
                  className={`mt-1.5 h-2 w-2 shrink-0 rounded-full bg-[#5b3bdf] ${
                    isSynthesizing ? 'animate-pulse' : ''
                  }`}
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs font-semibold text-[#0d1b3e] tabular-nums">
                    {progressPercent}% Processed
                  </p>
                  <p className="mt-0.5 text-[11px] text-[#45464e]">{progressDetail}</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0" aria-hidden="true">
                {[1, 2, 3, 4].map((step) => (
                  <span
                    key={step}
                    className={`h-1.5 w-6 rounded-full transition-colors duration-200 ${
                      step <= activeSegments ? 'bg-[#5b3bdf]' : 'bg-[#dcd6f7]'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Generator Footer CTA */}
            <div className="mt-5 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
              <div className="flex items-center gap-2 text-xs text-[#45464e]">
                <ShieldCheck className="h-4 w-4 text-[#5b3bdf]" />
                <span>
                  Targeting {sprintBaselineMode.toLowerCase()} baseline
                  {autoNotifyTeam ? ' • Auto-notifies engineering team' : ' • Silent draft mode'}
                </span>
              </div>

              <button
                type="button"
                disabled={isSynthesizing}
                onClick={handleSynthesize}
                className="inline-flex items-center gap-3 rounded-full bg-[#0d1b3e] py-2 pl-5 pr-2 text-xs font-semibold text-white shadow-[0_12px_24px_-6px_rgba(13,27,62,0.28)] transition-all duration-150 hover:bg-[#162756] disabled:opacity-60 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6344e7]"
              >
                <span>{isSynthesizing ? 'Synthesizing Scope...' : 'Create from Transcript'}</span>
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#6344e7] text-white">
                  <ArrowRight className="h-3.5 w-3.5" />
                </span>
              </button>
            </div>
          </div>
        </section>

        {/* Active Client Engagements Section */}
        <section className="mt-16" aria-label="Active Client Engagements">
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <div className="flex flex-wrap items-baseline gap-3">
                <h2 className="font-editorial text-[28px] leading-tight text-[#0d1b3e]">
                  Active Client Engagements
                </h2>
                <span className="text-xs font-medium text-[#76767f] tabular-nums">
                  · {projects.length} Active Projects
                </span>
              </div>
              <p className="mt-1 text-[13px] text-[#45464e]">
                Enterprise initiatives currently coordinated via NovaWorks orbital intelligence.
              </p>
            </div>

            {/* Search & Status Filter */}
            <div className="relative flex items-center gap-2">
              <div className="flex items-center gap-2 rounded-full border border-[#0d1b3e]/10 bg-white px-4 py-2 shadow-[0_2px_10px_-4px_rgba(13,27,62,0.06)] focus-within:border-[#6344e7]/40 focus-within:ring-2 focus-within:ring-[#6344e7]/15">
                <Search className="h-3.5 w-3.5 text-[#76767f]" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter projects or stacks..."
                  className="w-44 bg-transparent text-xs text-[#0d1b3e] placeholder:text-[#76767f] focus:outline-none sm:w-52"
                />
              </div>

              <button
                type="button"
                onClick={() => setFilterMenuOpen((prev) => !prev)}
                aria-label="Filter by project status"
                aria-expanded={filterMenuOpen}
                className={`flex h-9 w-9 items-center justify-center rounded-full border transition-colors ${
                  statusFilter !== 'ALL'
                    ? 'border-[#6344e7]/40 bg-[#f1edff] text-[#5b3bdf]'
                    : 'border-[#0d1b3e]/10 bg-white text-[#45464e] hover:bg-[#f5f4f0]'
                }`}
              >
                <SlidersHorizontal className="h-3.5 w-3.5" />
              </button>

              {filterMenuOpen && (
                <div className="absolute right-0 top-11 z-20 w-48 rounded-2xl border border-[#0d1b3e]/10 bg-white p-1.5 shadow-xl">
                  {availableStatuses.map((status) => (
                    <button
                      key={status}
                      type="button"
                      onClick={() => {
                        setStatusFilter(status);
                        setFilterMenuOpen(false);
                      }}
                      className={`flex w-full items-center justify-between rounded-xl px-3 py-1.5 text-left text-xs transition-colors ${
                        statusFilter === status
                          ? 'bg-[#f1edff] font-semibold text-[#5b3bdf]'
                          : 'text-[#45464e] hover:bg-[#faf9f5]'
                      }`}
                    >
                      <span>{status === 'ALL' ? 'All Statuses' : status}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* 3-Column Project Cards Grid */}
          {filteredProjects.length === 0 ? (
            <div className="mt-8 rounded-3xl border border-[#0d1b3e]/[0.08] bg-white p-12 text-center">
              <p className="font-editorial text-xl text-[#0d1b3e]">No matching engagements</p>
              <p className="mt-1 text-xs text-[#45464e]">
                Clear your search filter or synthesize a new client initiative above.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('ALL');
                }}
                className="mt-4 rounded-full bg-[#0d1b3e] px-5 py-2 text-xs font-semibold text-white hover:bg-[#162756]"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="mt-7 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredProjects.map((project) => {
                const isHighlight = project.isHighlightedCard;
                return (
                  <article
                    key={project.id}
                    onClick={() => onSelectProject(project.id)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        onSelectProject(project.id);
                      }
                    }}
                    tabIndex={0}
                    role="button"
                    className={`group flex cursor-pointer flex-col justify-between rounded-[1.5rem] bg-white p-6 transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6344e7] ${
                      isHighlight
                        ? 'border border-[#6344e7]/40 shadow-[0_12px_32px_-12px_rgba(99,68,231,0.16)] hover:border-[#6344e7]/70'
                        : 'border border-[#0d1b3e]/[0.07] shadow-[0_4px_20px_-8px_rgba(13,27,62,0.06)] hover:border-[#0d1b3e]/20 hover:shadow-[0_14px_30px_-10px_rgba(13,27,62,0.11)]'
                    }`}
                  >
                    <div>
                      {/* Card Eyebrow & Status */}
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className={`text-[10px] font-semibold uppercase tracking-[0.12em] whitespace-nowrap ${
                            isHighlight ? 'text-[#5b3bdf]' : 'text-[#76767f]'
                          }`}
                        >
                          {project.categoryEyebrow}
                        </span>

                        <span
                          className={`text-[11px] font-medium whitespace-nowrap ${
                            project.statusTone === 'iris' ? 'text-[#5b3bdf]' : 'text-[#45464e]'
                          }`}
                        >
                          {project.statusLabel}
                        </span>
                      </div>

                      {/* Client Name & Description */}
                      <h3 className="mt-4 text-[19px] font-semibold tracking-[-0.01em] text-[#0d1b3e] group-hover:text-[#5b3bdf] transition-colors">
                        {project.clientName}
                      </h3>
                      <p className="mt-1.5 line-clamp-2 text-[13px] leading-relaxed text-[#45464e]">
                        {project.summary}
                      </p>
                    </div>

                    <div>
                      {/* Lead + Date */}
                      <div className="mt-6 flex items-center justify-between gap-3 border-t border-[#0d1b3e]/[0.06] pt-4">
                        <div className="flex items-center gap-2.5 min-w-0">
                          {project.leadAvatar ? (
                            <img
                              src={project.leadAvatar}
                              alt={project.leadName}
                              referrerPolicy="no-referrer"
                              className="h-7 w-7 shrink-0 rounded-full object-cover ring-1 ring-[#0d1b3e]/10"
                            />
                          ) : (
                            <span
                              className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold text-white ${
                                project.leadInitials === 'AL' ? 'bg-[#6344e7]' : 'bg-[#0d1b3e]'
                              }`}
                            >
                              {project.leadInitials}
                            </span>
                          )}
                          <span className="truncate text-xs font-medium text-[#0d1b3e]">
                            {project.leadName}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5 text-[11px] text-[#76767f] tabular-nums shrink-0">
                          <Calendar className="h-3 w-3" />
                          <span>{project.dueDate}</span>
                        </div>
                      </div>

                      {/* Stack Tags & Arrow */}
                      <div className="mt-4 flex items-center justify-between gap-2">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {project.stackTags.map((tag) => {
                            const isTagHighlighted = project.highlightedTag === tag;
                            return (
                              <span
                                key={tag}
                                className={`rounded-lg px-2.5 py-1 text-[11px] font-medium ${
                                  isTagHighlighted
                                    ? 'bg-[#f1edff] text-[#5b3bdf]'
                                    : 'bg-[#f5f4f0] text-[#45464e]'
                                }`}
                              >
                                {tag}
                              </span>
                            );
                          })}
                        </div>

                        <span
                          className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-transform duration-150 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 ${
                            isHighlight
                              ? 'bg-[#f1edff] text-[#5b3bdf]'
                              : 'bg-[#f5f4f0] text-[#45464e] group-hover:bg-[#0d1b3e] group-hover:text-white'
                          }`}
                        >
                          <ArrowUpRight className="h-3.5 w-3.5" />
                        </span>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
