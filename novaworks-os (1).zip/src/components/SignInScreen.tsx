import React, { useState } from 'react';
import {
  ArrowRight,
  AtSign,
  Check,
  Eye,
  EyeOff,
  Lock,
  Shield,
  Terminal,
  Users,
} from 'lucide-react';
import { DemoUser } from '../types';
import { NovaWorksLogo } from './NovaWorksLogo';
import { OrbitalBackground } from './OrbitalBackground';

interface SignInScreenProps {
  demoUsers: DemoUser[];
  onSignInSuccess: (user: DemoUser) => void;
}

export const SignInScreen: React.FC<SignInScreenProps> = ({
  demoUsers,
  onSignInSuccess,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('••••••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberSession, setRememberSession] = useState(true);
  const [selectedDemoId, setSelectedDemoId] = useState<string | null>(null);
  const [infoNotice, setInfoNotice] = useState<string | null>(null);

  const handleSelectDemoRole = (user: DemoUser) => {
    setEmail(user.email);
    setPassword('novaworks-orbital-2025');
    setSelectedDemoId(user.id);
    setInfoNotice(`Autofilled credentials for ${user.name} (${user.roleLabel}).`);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const matched =
      demoUsers.find((u) => u.email.toLowerCase() === email.trim().toLowerCase()) ||
      demoUsers.find((u) => u.id === selectedDemoId) ||
      demoUsers[2]; // Default to Ali Raza (Staff Engineer) if custom email entered
    onSignInSuccess(matched);
  };

  const roleIcons: Record<string, React.ReactNode> = {
    ADMIN: <Shield className="h-4 w-4 text-[#5b3bdf]" />,
    MANAGER: <Users className="h-4 w-4 text-[#5b3bdf]" />,
    DEVELOPER: <Terminal className="h-4 w-4 text-[#5b3bdf]" />,
  };

  const roleBadgeClass: Record<string, string> = {
    ADMIN: 'bg-[#f1edff] text-[#5b3bdf]',
    MANAGER: 'bg-[#efeeea] text-[#45464e]',
    DEVELOPER: 'bg-[#efeeea] text-[#45464e]',
  };

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-between bg-[#faf9f5] px-4 py-8 sm:py-10">
      <OrbitalBackground variant="auth" />

      {/* Top Eyebrow */}
      <div className="relative z-10 text-center">
        <span className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#5b3bdf]">
          START FROM THE FUTURE
        </span>
      </div>

      {/* Centered Auth Card */}
      <main className="relative z-10 my-6 w-full max-w-[440px]">
        <div className="rounded-[2rem] border border-[#0d1b3e]/[0.07] bg-white p-7 shadow-[0_24px_60px_-20px_rgba(13,27,62,0.12)] sm:p-10">
          <div className="flex flex-col items-center text-center">
            <NovaWorksLogo size="md" />
            <h1 className="mt-5 font-editorial text-[30px] leading-[1.15] tracking-[-0.015em] text-[#0d1b3e]">
              Sign in to NovaWorks OS
            </h1>
            <p className="mt-2.5 max-w-[330px] text-[13px] leading-relaxed text-[#45464e]">
              The AI-native Operating System designed to unify people, agents, and processes across the enterprise.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="mt-7 space-y-4">
            {/* Email Field */}
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label htmlFor="nw-email" className="text-xs font-medium text-[#0d1b3e]">
                  Enterprise Work Email
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setInfoNotice('SAML 2.0 / OIDC institutional SSO active for @novaworks.example.')
                  }
                  className="text-[11px] font-medium text-[#5b3bdf] hover:underline"
                >
                  SSO Enabled
                </button>
              </div>
              <div className="flex items-center gap-2.5 rounded-2xl border border-[#0d1b3e]/[0.08] bg-[#f5f4f0] px-3.5 py-2.5 transition-shadow focus-within:border-[#6344e7]/40 focus-within:ring-3 focus-within:ring-[#6344e7]/15">
                <AtSign className="h-4 w-4 shrink-0 text-[#76767f]" />
                <input
                  id="nw-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="colleague@enterprise.com"
                  className="w-full bg-transparent text-sm text-[#0d1b3e] placeholder:text-[#76767f]/80 focus:outline-none"
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label htmlFor="nw-password" className="text-xs font-medium text-[#0d1b3e]">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setInfoNotice('Password reset links are issued through your security administrator or Quick Demo Access below.')
                  }
                  className="text-[11px] font-medium text-[#5b3bdf] hover:underline"
                >
                  Forgot password?
                </button>
              </div>
              <div className="flex items-center gap-2.5 rounded-2xl border border-[#0d1b3e]/[0.08] bg-[#f5f4f0] px-3.5 py-2.5 transition-shadow focus-within:border-[#6344e7]/40 focus-within:ring-3 focus-within:ring-[#6344e7]/15">
                <Lock className="h-4 w-4 shrink-0 text-[#76767f]" />
                <input
                  id="nw-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter access passphrase"
                  className="w-full bg-transparent text-sm text-[#0d1b3e] placeholder:text-[#76767f]/80 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="rounded-md p-0.5 text-[#76767f] hover:text-[#0d1b3e]"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Remember Session Checkbox */}
            <div className="flex items-center justify-between pt-0.5">
              <button
                type="button"
                role="checkbox"
                aria-checked={rememberSession}
                onClick={() => setRememberSession((prev) => !prev)}
                className="flex items-center gap-2.5 text-left text-xs text-[#45464e] hover:text-[#0d1b3e]"
              >
                <span
                  className={`flex h-4 w-4 items-center justify-center rounded-[5px] border transition-colors ${
                    rememberSession
                      ? 'border-[#5b3bdf] bg-[#5b3bdf] text-white'
                      : 'border-[#c6c6cf] bg-white'
                  }`}
                >
                  {rememberSession && <Check className="h-3 w-3 stroke-[3]" />}
                </span>
                <span>Remember session on this device</span>
              </button>
            </div>

            {infoNotice && (
              <p className="rounded-xl bg-[#f1edff] px-3 py-2 text-[11px] font-medium text-[#4519ca]">
                {infoNotice}
              </p>
            )}

            {/* Primary CTA Pill */}
            <div className="flex justify-center pt-2">
              <button
                type="submit"
                className="inline-flex items-center gap-4 rounded-full bg-[#0d1b3e] py-2 pl-6 pr-2 text-xs font-semibold tracking-[0.12em] text-white shadow-[0_12px_24px_-6px_rgba(13,27,62,0.28)] transition-all duration-150 hover:bg-[#162756] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6344e7]"
              >
                <span>SIGN IN</span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#6344e7] text-white">
                  <ArrowRight className="h-4 w-4" />
                </span>
              </button>
            </div>
          </form>

          {/* Divider with Center Dot */}
          <div className="relative my-6 flex items-center justify-center">
            <div className="h-px w-full bg-[#0d1b3e]/[0.07]" />
            <span
              className="absolute h-2 w-2 rounded-full bg-[#c9bfff] ring-4 ring-white"
              aria-hidden="true"
            />
          </div>

          {/* Quick Demo Access Box */}
          <div className="rounded-2xl bg-[#f5f4f0] p-4">
            <div className="mb-3 flex items-center justify-between gap-2">
              <span className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#5b3bdf]">
                QUICK DEMO ACCESS
              </span>
              <span className="text-[11px] text-[#76767f]">Click role to autofill</span>
            </div>

            <div className="space-y-2">
              {demoUsers.map((user) => {
                const isSelected = selectedDemoId === user.id;
                return (
                  <button
                    key={user.id}
                    type="button"
                    onClick={() => handleSelectDemoRole(user)}
                    className={`flex w-full items-center justify-between gap-3 rounded-xl border bg-white px-3.5 py-2.5 text-left transition-all duration-150 ${
                      isSelected
                        ? 'border-[#6344e7]/45 ring-2 ring-[#6344e7]/15'
                        : 'border-[#0d1b3e]/[0.06] hover:border-[#0d1b3e]/20'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#f1edff]">
                        {roleIcons[user.role]}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-[#0d1b3e] truncate">
                          {user.roleLabel}
                        </p>
                        <p className="text-[11px] text-[#76767f] truncate">{user.email}</p>
                      </div>
                    </div>

                    <span className="shrink-0 text-[10px] font-semibold tracking-wider text-[#5b3bdf]">
                      {user.role}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Status & Copyright */}
      <footer className="relative z-10 text-center">
        <p className="text-xs text-[#45464e]">
          Enterprise Multi-Agent Orchestration Active
        </p>
        <p className="mt-1.5 text-[11px] text-[#76767f]">
          © 2025 NovaWorks Technologies. Enterprise AI Workforce OS.
        </p>
      </footer>
    </div>
  );
};
