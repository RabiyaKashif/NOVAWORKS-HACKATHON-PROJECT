export type AppScreen = 'projects' | 'tasks' | 'team' | 'signin';

export type UserRole = 'ADMIN' | 'MANAGER' | 'DEVELOPER';

export interface DemoUser {
  id: string;
  roleLabel: string;
  name: string;
  email: string;
  initials: string;
  role: UserRole;
  title: string;
  specialty: string;
}

export type TaskStatus = 'In Development' | 'Under Review' | 'Completed' | 'Queued';

export type TaskIconKind = 'lock' | 'calculator' | 'bell' | 'shield' | 'layers' | 'cpu';

export interface TaskItem {
  id: string;
  code: string;
  title: string;
  description: string;
  status: TaskStatus;
  assigneeName: string;
  assigneeInitials: string;
  assigneeSpecialty: string;
  hours: number;
  deadline: string;
  deadlineSort: string;
  icon: TaskIconKind;
  executionOrder: number;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  detail: string;
}

export interface Project {
  id: string;
  code: string;
  categoryEyebrow: string;
  clientName: string;
  projectTitle: string;
  summary: string;
  architectureSummary: string;
  statusLabel: string;
  statusTone: 'iris' | 'slate' | 'emerald';
  priority: 'HIGH PRIORITY' | 'STANDARD' | 'CRITICAL';
  workflowState: 'IN PROGRESS' | 'SCOPED' | 'TESTING' | 'PLANNING';
  leadName: string;
  leadInitials: string;
  leadAvatar?: string;
  deliveryLeadName: string;
  deliveryLeadRole: string;
  targetDelivery: string;
  sprintLabel: string;
  clientContactName: string;
  clientContactEmail: string;
  dueDate: string;
  stackTags: string[];
  highlightedTag?: string;
  isHighlightedCard?: boolean;
  tasks: TaskItem[];
  closedCount: number;
  underReviewCount: number;
  auditLog: AuditEntry[];
  sprintSpecs: string[];
}

export type MemberRoleType = 'ADMIN' | 'MANAGER' | 'AGENT';

export interface TeamMember {
  id: string;
  name: string;
  initials: string;
  roleType: MemberRoleType;
  title: string;
  email: string;
  capabilities: string[];
  highlightedCapability: string;
  squad: string;
  location: string;
}
