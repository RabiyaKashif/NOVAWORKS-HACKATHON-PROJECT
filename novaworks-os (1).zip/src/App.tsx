/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useMemo, useState } from 'react';
import { Footer } from './components/Footer';
import { ProjectsScreen } from './components/ProjectsScreen';
import { SignInScreen } from './components/SignInScreen';
import { TasksScreen } from './components/TasksScreen';
import { TeamDirectoryScreen } from './components/TeamDirectoryScreen';
import { TopNavBar } from './components/TopNavBar';
import { DEMO_USERS, INITIAL_PROJECTS, TEAM_MEMBERS } from './data/mockData';
import { AppScreen, DemoUser, Project, TaskItem } from './types';

const KNOWN_STACKS = [
  'Go',
  'Kubernetes',
  'GraphQL',
  'React',
  'Python',
  'PostgreSQL',
  'Flutter',
  'Swift',
  'Rust',
  'Kafka',
  'AWS',
  'TypeScript',
  'MQTT',
  'Azure',
  'Next.js',
  'Node',
  'Docker',
  'PyTorch',
  'Terraform',
];

function synthesizeProjectFromTranscript(transcript: string, existingCount: number): Project {
  const lower = transcript.toLowerCase();
  const lines = transcript
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);

  let clientName = 'Vertex Sovereign';
  let projectTitle = 'Autonomous Cloud Platform';
  let categoryEyebrow = 'AI GENERATED • RECENT';

  if (lower.includes('vanguard')) {
    clientName = 'Vanguard Institutional';
    projectTitle = 'Multi-Custodian Liquidity Hub';
    categoryEyebrow = 'AI GENERATED • TREASURY';
  } else if (lower.includes('meridian')) {
    clientName = 'Meridian BioGrid';
    projectTitle = 'Cryo-Chamber Telemetry Pipeline';
    categoryEyebrow = 'AI GENERATED • DIAGNOSTICS';
  } else if (lower.includes('omnicorp')) {
    clientName = 'OmniCorp Vault';
    projectTitle = 'Multi-Region Audit Vault';
  } else if (lines[0]) {
    const cleaned = lines[0]
      .replace(/^(client call|client sync|meeting|notes)\s*[—:-]?\s*/i, '')
      .replace(/\(.*?\)/g, '')
      .trim();
    if (cleaned.length > 2) {
      const words = cleaned.split(/\s+/).slice(0, 3);
      clientName = words.slice(0, 2).join(' ');
      projectTitle = cleaned.slice(0, 42);
    }
  }

  const matchedStacks = KNOWN_STACKS.filter((stack) =>
    lower.includes(stack.toLowerCase())
  ).slice(0, 3);
  const stackTags = matchedStacks.length > 0 ? matchedStacks : ['Go', 'TypeScript', 'AWS'];

  const codePrefix = clientName
    .replace(/[^A-Za-z]/g, '')
    .slice(0, 3)
    .toUpperCase()
    .padEnd(3, 'X');
  const code = `${codePrefix}-${700 + existingCount * 17}`;
  const baseTaskNum = 9100 + existingCount * 20;

  const summarySnippet =
    lines.find((l) => l.startsWith('-'))?.replace(/^-\s*/, '') ||
    lines.slice(0, 2).join(' ').slice(0, 120) ||
    'Synthesized institutional engineering sprint with automated milestone verification.';

  const tasks: TaskItem[] = [
    {
      id: `syn-${Date.now()}-1`,
      code: `NW-${baseTaskNum + 1}`,
      title: `${stackTags[0]} Core Architecture & Secure Gateway`,
      description: `Establish zero-trust service boundaries, key rotation, and schema contracts for ${clientName}.`,
      status: 'In Development',
      assigneeName: 'Ali Raza',
      assigneeInitials: 'AR',
      assigneeSpecialty: 'Mobile / Systems',
      hours: 14,
      deadline: 'Jan 24, 2026',
      deadlineSort: '2026-01-24',
      icon: 'lock',
      executionOrder: 1,
    },
    {
      id: `syn-${Date.now()}-2`,
      code: `NW-${baseTaskNum + 4}`,
      title: `Real-Time Telemetry & Event Reconciliation`,
      description: `Implement deterministic stream processing and encrypted audit sinks across ${stackTags.join(
        ', '
      )} nodes.`,
      status: 'Under Review',
      assigneeName: 'Tariq Mansoor',
      assigneeInitials: 'TM',
      assigneeSpecialty: 'Backend / Go',
      hours: 16,
      deadline: 'Feb 02, 2026',
      deadlineSort: '2026-02-02',
      icon: 'cpu',
      executionOrder: 2,
    },
    {
      id: `syn-${Date.now()}-3`,
      code: `NW-${baseTaskNum + 7}`,
      title: `Executive Operational Console & Alert Hooks`,
      description: `Deliver responsive triage console with automated policy notifications and audit exports.`,
      status: 'Queued',
      assigneeName: 'Sarah Jenkins',
      assigneeInitials: 'SJ',
      assigneeSpecialty: 'Frontend / React',
      hours: 12,
      deadline: 'Feb 11, 2026',
      deadlineSort: '2026-02-11',
      icon: 'bell',
      executionOrder: 3,
    },
    {
      id: `syn-${Date.now()}-4`,
      code: `NW-${baseTaskNum + 9}`,
      title: `Compliance Verification & Load Soak Suite`,
      description: `Execute end-to-end cryptographic policy checks and failover simulation prior to production sign-off.`,
      status: 'Queued',
      assigneeName: 'Priya Chen',
      assigneeInitials: 'PC',
      assigneeSpecialty: 'QA / Automation',
      hours: 10,
      deadline: 'Feb 18, 2026',
      deadlineSort: '2026-02-18',
      icon: 'shield',
      executionOrder: 4,
    },
  ];

  return {
    id: `proj-syn-${Date.now()}`,
    code,
    categoryEyebrow,
    clientName,
    projectTitle,
    summary: summarySnippet,
    architectureSummary: `${summarySnippet} Coordinated via Orbital Engine v2.4 across ${stackTags.join(
      ' / '
    )}.`,
    statusLabel: 'Scoped',
    statusTone: 'iris',
    priority: 'HIGH PRIORITY',
    workflowState: 'SCOPED',
    leadName: 'Ayesha Khan',
    leadInitials: 'AK',
    deliveryLeadName: 'Ayesha Khan',
    deliveryLeadRole: 'AI PM • Delivery Lead',
    targetDelivery: 'February 18, 2026',
    sprintLabel: 'Sprint Alpha',
    clientContactName: 'Enterprise Stakeholder',
    clientContactEmail: `ops@${clientName.toLowerCase().replace(/\s+/g, '')}.com`,
    dueDate: 'Feb 18, 2026',
    stackTags,
    highlightedTag: stackTags[0],
    isHighlightedCard: true,
    closedCount: 0,
    underReviewCount: 1,
    tasks,
    auditLog: [
      {
        id: `aud-syn-${Date.now()}`,
        timestamp: 'Just now',
        actor: 'Orbital Engine v2.4',
        action: `Synthesized ${tasks.length} work packages from meeting transcript`,
        detail: `Matched ${stackTags.join(', ')} specialists across NovaWorks squads.`,
      },
    ],
    sprintSpecs: [
      `Primary stack baseline locked to ${stackTags.join(', ')}.`,
      'Zero-trust session enforcement and immutable sprint audit log enabled.',
    ],
  };
}

export default function App() {
  const [activeScreen, setActiveScreen] = useState<AppScreen>('projects');
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('proj-apex');
  const [isAdminView, setIsAdminView] = useState<boolean>(true);
  const [currentUser, setCurrentUser] = useState<DemoUser>(DEMO_USERS[2]); // Ali Raza (Developer)

  const selectedProject = useMemo(() => {
    return projects.find((p) => p.id === selectedProjectId) || projects[0];
  }, [projects, selectedProjectId]);

  const handleSelectProject = (projectId: string) => {
    setSelectedProjectId(projectId);
    setActiveScreen('tasks');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigate = (screen: AppScreen) => {
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCreateProjectFromTranscript = (transcript: string): Project => {
    const newProject = synthesizeProjectFromTranscript(transcript, projects.length);
    setProjects((prev) => [
      newProject,
      ...prev.map((p) => ({ ...p, isHighlightedCard: false })),
    ]);
    setSelectedProjectId(newProject.id);
    return newProject;
  };

  const handleUpdateTask = (projectId: string, updatedTask: TaskItem) => {
    setProjects((prev) =>
      prev.map((project) => {
        if (project.id !== projectId) return project;
        const nextTasks = project.tasks.map((t) => (t.id === updatedTask.id ? updatedTask : t));
        return {
          ...project,
          tasks: nextTasks,
          underReviewCount: nextTasks.filter((t) => t.status === 'Under Review').length,
        };
      })
    );
  };

  const handleAddTask = (
    projectId: string,
    newTaskData: Omit<TaskItem, 'id' | 'code' | 'executionOrder'>
  ) => {
    setProjects((prev) =>
      prev.map((project) => {
        if (project.id !== projectId) return project;
        const nextOrder = project.tasks.length + 1;
        const newTask: TaskItem = {
          ...newTaskData,
          id: `task-${Date.now()}`,
          code: `NW-${8420 + nextOrder * 3}`,
          executionOrder: nextOrder,
        };
        const nextTasks = [...project.tasks, newTask];
        return {
          ...project,
          tasks: nextTasks,
          underReviewCount: nextTasks.filter((t) => t.status === 'Under Review').length,
        };
      })
    );
  };

  const handleSignInSuccess = (user: DemoUser) => {
    setCurrentUser(user);
    setIsAdminView(user.role === 'ADMIN');
    setActiveScreen('projects');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickSwitchUser = (user: DemoUser) => {
    setCurrentUser(user);
    setIsAdminView(user.role === 'ADMIN');
  };

  if (activeScreen === 'signin') {
    return <SignInScreen demoUsers={DEMO_USERS} onSignInSuccess={handleSignInSuccess} />;
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#faf9f5] text-[#1b1c1a]">
      <TopNavBar
        activeScreen={activeScreen}
        onNavigate={handleNavigate}
        isAdminView={isAdminView}
        onToggleAdminView={() => setIsAdminView((prev) => !prev)}
        currentUser={currentUser}
        onOpenSignIn={() => handleNavigate('signin')}
        onQuickSwitchUser={handleQuickSwitchUser}
        demoUsers={DEMO_USERS}
      />

      <main className="flex-1">
        {activeScreen === 'projects' && (
          <ProjectsScreen
            projects={projects}
            onSelectProject={handleSelectProject}
            onCreateProjectFromTranscript={handleCreateProjectFromTranscript}
          />
        )}

        {activeScreen === 'tasks' && selectedProject && (
          <TasksScreen
            project={selectedProject}
            allProjects={projects}
            currentUser={currentUser}
            isAdminView={isAdminView}
            teamMembers={TEAM_MEMBERS}
            onBackToProjects={() => handleNavigate('projects')}
            onSelectProjectId={(id) => setSelectedProjectId(id)}
            onUpdateTask={handleUpdateTask}
            onAddTask={handleAddTask}
          />
        )}

        {activeScreen === 'team' && (
          <TeamDirectoryScreen
            members={TEAM_MEMBERS}
            projects={projects}
            onNavigateToProject={handleSelectProject}
          />
        )}
      </main>

      <Footer />
    </div>
  );
}
